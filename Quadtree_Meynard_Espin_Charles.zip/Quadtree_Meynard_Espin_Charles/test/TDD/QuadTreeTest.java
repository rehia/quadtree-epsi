package TDD;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test;
import static org.junit.Assert.*;
import quadtree2.Node;
import quadtree2.Point;
import quadtree2.Quadtree2;
import quadtree2.RepereDeLarbre;

/**
 *
 * @author Fran�ois
 */
public class QuadTreeTest {
    
    public QuadTreeTest() {
    }
    
 
     @Test
     public void shouldCreateATreeWithoutChildren() 
     {
         Quadtree2 mainTree = new Quadtree2(new Node());
         assertEquals(0, mainTree.getPointsDeLarbre().size());
     }
      @Test
     public void shouldAddFourPoints() 
     {
         Quadtree2 mainTree = new Quadtree2(new Node(0,0,100,100));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(20,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(60,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         
         assertEquals(4, mainTree.getRoot().compteLeNombreDeNoeud());
     }
     @Test
     public void shouldDivideHeightPoints() 
     {
         Quadtree2 mainTree = new Quadtree2(new Node(0,0,100,100));
         
         mainTree.ajouteUnPointAuBonNoeuds(new Point(20,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(60,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         
         mainTree.ajouteUnPointAuBonNoeuds(new Point(20,60));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(60,40));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,80));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,80));
         assertEquals(8, mainTree.getPointsDeLarbre().size());
     }
     
     @Test
     public void ShouldNotCreateChildren() 
     {
         Quadtree2 mainTree = new Quadtree2(new Node(0,0,100,100));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(20,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(60,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         
         assertEquals(0, mainTree.getRoot().compteLeNombreDenfant());
     }
     
     @Test
     public void ShouldCreateChildren() 
     {
         Quadtree2 mainTree = new Quadtree2(new Node(0,0,100,100));
         
         mainTree.ajouteUnPointAuBonNoeuds(new Point(20,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(60,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         
         mainTree.ajouteUnPointAuBonNoeuds(new Point(20,60));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(60,40));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,80));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,80));
        
         assertEquals(4, mainTree.getRoot().compteLeNombreDenfant());
     }
     
     @Test
     public void ShouldPointIsInNode() 
     {
         Quadtree2 mainTree = new Quadtree2(new Node(0,0,100,100));
         
         Point point_to_test = new Point(60,20);
         mainTree.ajouteUnPointAuBonNoeuds(new Point(20,20));
         mainTree.ajouteUnPointAuBonNoeuds(point_to_test);
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,60));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,70));
         
         assertEquals(true, ((Node)mainTree.getRoot().getEnfants().get(RepereDeLarbre.BasDroite)).getPointsDuNoeud().contains(point_to_test));
     }
     
     @Test
     public void ShouldPointIsNotInNode() 
     {
         Quadtree2 mainTree = new Quadtree2(new Node(0,0,100,100));
         
         Point point_to_test = new Point(60,20);
         Point point_where_is_not_in_node = new Point(20,20);
         mainTree.ajouteUnPointAuBonNoeuds(point_where_is_not_in_node);
         mainTree.ajouteUnPointAuBonNoeuds(point_to_test);
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,20));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,60));
         mainTree.ajouteUnPointAuBonNoeuds(new Point(80,70));
         
         assertNotEquals(true, ((Node)mainTree.getRoot().getEnfants().get(RepereDeLarbre.BasDroite)).getPointsDuNoeud().contains(point_where_is_not_in_node));
     }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
