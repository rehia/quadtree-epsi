package TDD;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import org.junit.Test;
import static org.junit.Assert.*;
import quadtree2.Node;
import quadtree2.Point;

/**
 *
 * @author Nox
 */
public class NodeTest {
    
    public NodeTest() {
    }
    
    @Test
    public void souldBeALeaf()
    {
        Node nodeWithoutChild = new Node(10,10,50,50); 
        
        assertEquals(true, nodeWithoutChild.estUneFeuille());
    }
    
    @Test
    public void SouldCreateFourChild()
    {
        Node nodeWithChild = new Node(10,10,50,50);
        nodeWithChild.CreationFeuilles();
        assertEquals(4, nodeWithChild.compteLeNombreDenfant());
    }
    
    @Test
    public void shouldBugBecauseHaveChild()
    {
        Node nodeWithChild = new Node(10,10,50,50);
        nodeWithChild.CreationFeuilles();
         
        assertNotEquals(0, nodeWithChild.compteLeNombreDenfant()); 
    }
    
    
    @Test
    public void souldHaveNoChild()
    {
        Node nodeWithChild = new Node(10,10,50,50);
        
        assertEquals(0, nodeWithChild.compteLeNombreDeNoeud());
    }
    
    
    @Test
    public void souldCreateLeafAndClearPoints()
    {
        Node nodeWithChild = new Node(10,10,50,50);
        nodeWithChild.AjouterUnPoint(new Point(20,20));
        nodeWithChild.AjouterUnPoint(new Point(60,20));
        nodeWithChild.AjouterUnPoint(new Point(80,20));
        nodeWithChild.AjouterUnPoint(new Point(80,20));
        nodeWithChild.DiviseEnFeuille();
        
        assertEquals(0, nodeWithChild.compteLeNombreDeNoeud());
    }
}
