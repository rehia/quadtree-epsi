/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quadtree2;

public class Point {
    
    private double x;
    private double y;
    
    
    public Point(double x, double y){
        this.x=x;
        this.y=y;
    }
    
    public Point(){}

    @Override
    public String toString(){
        System.out.println(nom_point());
        return nom_point();
    }
    
    public String nom_point(){
        String messageDeSortie = "Point("+ "("+ String.valueOf(x) +","+String.valueOf(y)+")";
        return messageDeSortie;
        
    }  
    
    /**
     * @return the x
     */
    public double getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public double getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(double y) {
        this.y = y;
    }


}
