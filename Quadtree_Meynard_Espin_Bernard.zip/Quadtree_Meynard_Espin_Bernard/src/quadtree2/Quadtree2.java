/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quadtree2;

import java.util.ArrayList;

public class Quadtree2{
    
    
    private Node root;
    private ArrayList<Point> pointsDeLarbre; 
    
    public Quadtree2(Node root){
        this.root = root;
        this.pointsDeLarbre = new ArrayList<Point>();
        
    }
    
    public void ajouteUnPointAuBonNoeuds(Point unPoint)
    {
        getRoot().AjouterUnPoint(unPoint);
        pointsDeLarbre.add(unPoint);
        
    }
    
    @Override
    public String toString()
    {
        String messageAAfficher="";
        if(this.root.estUneFeuille()){
          //  System.out.println("coucou");
        }
        this.getRoot();
        return messageAAfficher;
    }

    /**
     * @return the pointsDeLarbre
     */
    public ArrayList<Point> getPointsDeLarbre() {
        return pointsDeLarbre;
    }

    /**
     * @return the root
     */
    public Node getRoot() {
        return root;
    } 
}
