/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quadtree2;

import java.util.ArrayList;
import java.util.HashMap;

public class Node {

   
  
    
    private ArrayList<Point> pointsDuNoeud;
    private HashMap<RepereDeLarbre,Node> enfants;
    private double x;
    private double y;
    private double hauteur;
    private double largeur;
    

    public Node() {}  
    public Node(double X, double Y, double Largeur, double Hauteur) 
    {
        this.enfants = new HashMap<RepereDeLarbre, Node>();
        this.pointsDuNoeud = new ArrayList<Point>();
        this.x = X;
        this.y = Y;
        this.largeur = Largeur;
        this.hauteur = Hauteur; 
        
    }
  
    public boolean estUneFeuille()
    {
        boolean isLeaf = false;
        if( enfants.isEmpty())
            isLeaf = true;
        return isLeaf;
    }
    
    public void CreationFeuilles()
    {

        double milieuX = RetourneCentreDeX(this.x,this.largeur);
        double milieuY = retourneCentreDeY(this.y, this.hauteur);
        double MoitieDeHauteur = this.hauteur/2;
        double MoitieDeLargeur = this.largeur/2;
        
        enfants.putIfAbsent(RepereDeLarbre.BasGauche, new Node(this.x,this.y,MoitieDeLargeur,MoitieDeHauteur));
        enfants.putIfAbsent(RepereDeLarbre.HautGauche, new Node(this.x,milieuY,MoitieDeLargeur,MoitieDeHauteur));
        enfants.putIfAbsent(RepereDeLarbre.BasDroite, new Node(milieuX,this.y,MoitieDeLargeur,MoitieDeHauteur));
        enfants.putIfAbsent(RepereDeLarbre.HautDroite, new Node(milieuX,milieuY, MoitieDeLargeur,MoitieDeHauteur));
    }
    
    public boolean nombreEnfantMaximumAtteind()
    {
        boolean isReached = false;
        if(this.pointsDuNoeud.size() == 4)
            isReached =true;
        
        return isReached;
    }
    
    public int compteLeNombreDenfant()
    {
        return this.enfants.size();
    }
    public int compteLeNombreDeNoeud()
    {
        return this.pointsDuNoeud.size();
    }
    
    public void DiviseEnFeuille()
    {   
        this.CreationFeuilles();
        for (Point unPointDuNoeud : this.pointsDuNoeud)
        {
            
            
            this.enfants.get(RepereDeLarbre.HautGauche).AjouterUnPoint(unPointDuNoeud);
            this.enfants.get(RepereDeLarbre.HautDroite).AjouterUnPoint(unPointDuNoeud);
            this.enfants.get(RepereDeLarbre.BasDroite).AjouterUnPoint(unPointDuNoeud);
            this.enfants.get(RepereDeLarbre.BasGauche).AjouterUnPoint(unPointDuNoeud);

        }
      
        this.pointsDuNoeud = new ArrayList<>();
    }
    
    public void ajouterDesPointAuxEnfants(Point pointActuel)
    {
        if(estUneFeuille())
        {
            DiviseEnFeuille();
        }
        this.enfants.get(RepereDeLarbre.HautGauche).AjouterUnPoint(pointActuel);
        this.enfants.get(RepereDeLarbre.HautDroite).AjouterUnPoint(pointActuel);
        this.enfants.get(RepereDeLarbre.BasDroite).AjouterUnPoint(pointActuel);
        this.enfants.get(RepereDeLarbre.BasGauche).AjouterUnPoint(pointActuel);
        
    }
    
    public void AjouterUnPoint(Point pointConcerner)
    {
        boolean doitEtreAjouterDansUnAutreNoeud = true; 
        if(this.x >pointConcerner.getX() || this.y > pointConcerner.getY() || pointConcerner.getX() > x + largeur || pointConcerner.getY() > y+ hauteur )
                doitEtreAjouterDansUnAutreNoeud =false;
        
        if(doitEtreAjouterDansUnAutreNoeud)
            if(nombreEnfantMaximumAtteind())
                ajouterDesPointAuxEnfants(pointConcerner);
            else
                this.pointsDuNoeud.add(pointConcerner);
    }
    
    private double RetourneCentreDeX(double x, double largeurTotale)
    {
        return Math.abs((x - largeurTotale)/2);
    }
    private double retourneCentreDeY(double y, double hauteurTotale)
    {
        return Math.abs((y - hauteurTotale)/2);
    }
    
    /**
     * @return the x
     */
    public double getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public double getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(double y) {
        this.y = y;
    }
    
    /**
     * @return the pointsDuNoeud
     */
    public ArrayList<Point> getPointsDuNoeud() {
        return pointsDuNoeud;
    }

    /**
     * @param pointsDuNoeud the pointsDuNoeud to set
     */
    public void setPointsDuNoeud(ArrayList<Point> pointsDuNoeud) {
        this.pointsDuNoeud = pointsDuNoeud;
    }

    /**
     * @return the enfants
     */
    public HashMap getEnfants() {
        return enfants;
    }

    /**
     * @param enfants the enfants to set
     */
    public void setEnfants(HashMap enfants) {
        this.enfants = enfants;
    }
   

    @Override
    public String toString(){
        
        String messageDeSortie = "";
        if (this.estUneFeuille())
        {
            messageDeSortie= "Noeud " +this.pointsDuNoeud.size()+ " "+ x+ " "+ y;
        }
        else
        {
            messageDeSortie =  "Noeud " +this.pointsDuNoeud.size()+ " "+ x+ " "+ y;
        }
        System.out.println(messageDeSortie);
        return messageDeSortie;
        
    }
    
}
